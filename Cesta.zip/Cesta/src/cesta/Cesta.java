package cesta;

/**
 *
 * @author arthur.frguimaraes
 */
import composicao.*;

public class Cesta {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Criando a cesta
        Composicao cesta = new Composicao("Cesta nova");
         //Criando Prod
        Componente p1 = new Leaf("bolo", 4.21);
        Componente p2 = new Leaf("copo", 5.21);
        Componente p3 = new Leaf("pao", 7.21);
        
        // adicionando prod
        
        cesta.adicionar(p1);
        cesta.adicionar(p2);
        cesta.adicionar(p3);
        
        // Criando bombom's
        Componente p4 = new Leaf("Macujara",20);
        Componente p5 = new Leaf("acerola",10);
        Componente p6 = new Leaf("murangu",5);
        // Caixa de bombom
        Composicao caixa = new Composicao("Caixa de bombom");
        
        caixa.adicionar(p4);
        caixa.adicionar(p5);
        caixa.adicionar(p6);
        cesta.adicionar(caixa);
        
        
        
        System.out.println(cesta.getPreco());
        System.out.println(cesta + " \n " + caixa);
        
        

    }

}
