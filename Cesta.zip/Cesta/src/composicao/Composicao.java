/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package composicao;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author arthur.frguimaraes
 */
public class Composicao implements Componente {

    private List<Componente> listaProduto;
    private String nome;

    public Composicao(String Nome) {
        listaProduto = new ArrayList<>();
        this.nome = nome;

    }
    
    public void adicionar (Componente componente) {
        listaProduto.add(componente);
    }
    public void remover (Componente componente) {
        listaProduto.remove(componente);
    }

    @Override
    public String toString() {
        return "Composicao{" + "listaProduto=" + listaProduto + ", nome=" + nome + '}';
    }
    
    

    @Override
    public double getPreco() {
        double total = 0;
        for(Componente c:listaProduto){
            total +=c.getPreco();
    }
        return total;
        
        
        
    }

    
}
