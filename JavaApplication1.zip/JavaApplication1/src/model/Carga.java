package model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author arthur.frguimaraes
 */
public class Carga {
    
    private double peso;
    private String descricao;

    public Carga() {
    }
    
    

    public Carga(double peso, String descricao) {
        this.peso = peso;
        this.descricao = descricao;
    }

    public double getPeso() {
        return peso;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Carga{" + "peso=" + peso + ", descricao=" + descricao + '}';
    }
     
    
}
