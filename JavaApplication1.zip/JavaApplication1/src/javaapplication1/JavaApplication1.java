package javaapplication1;

/**
 *
 * @author arthur.frguimaraes
 */

 import model.*;
 import strategy.*;


public class JavaApplication1 {
   
    public static void main(String[] args) {
        
        // Aug 0
        Carga carga = new Carga(12, "maryjane");
        // cria scanner pro usuario escolher a empresa
        double frete = ListaEmpresas.values()[5].calcularFrete(carga);
//        System.out.println(calcularFrete("ABC",carga));
System.out.println(frete);
       
    }
    
//    public static double calcularFrete(String nomeEmpresa, Carga carga){
//        CalcFrete empresa;
        
        
        
        
        
        
        
        
        
        
//        if(nomeEmpresa.equals("ABC")) {
//            empresa = new ABC();
//        }
//        
//         
//        else if(nomeEmpresa.equals("CBA")) {
//            empresa = new ABC();
//        }
//        
//         
//       else if(nomeEmpresa.equals("XPTO")) {
//            empresa = new ABC();
//        }
//        
//       else {
//           throw new IllegalCallerException("Opção inválida");
//       }
//        
//        return empresa.calcularFrete(carga);
//        
//    }

}
