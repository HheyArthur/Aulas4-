/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;

/**
 *
 * @author arthur.frguimaraes
 */
import model.*;

public class ABC implements CalcFrete{
 
    @Override
        public double calcularFrete (Carga carga){

         if(carga.getPeso()<=10){
                return 14.56;
            } else if (carga.getPeso()<=20){
                return 16.99;
            } else {
                return 100;
            
}
}
}

