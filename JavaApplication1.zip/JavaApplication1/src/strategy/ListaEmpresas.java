/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package strategy;

/**
 *
 * @author arthur.frguimaraes
 */
import model.*;

public enum ListaEmpresas implements CalcFrete {
    //classe interna

    ABC {
        @Override
        public double calcularFrete(Carga carga) {
            if (carga.getPeso() <= 10) {
                return 14.56;
            } else if (carga.getPeso() <= 20) {
                return 16.99;
            } else {
                return 100;
            }

        }
    },
    CBA {
        @Override
        public double calcularFrete(Carga carga) {
            if (carga.getPeso() <= 10) {
                return 12.56;
            } else if (carga.getPeso() <= 20) {
                return 14.99;
            } else {
                return 50;
            }

        }
    },
    XPTO {
        @Override
        public double calcularFrete(Carga carga) {

            if (carga.getPeso() <= 10) {
                return 12.56;
            } else if (carga.getPeso() <= 20) {
                return 14.99;
            } else {
                return 50;
            }

        }

    }
};
