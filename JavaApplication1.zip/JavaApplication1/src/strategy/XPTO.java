/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;

/**
 *
 * @author arthur.frguimaraes
 */
import model.*;

public class XPTO implements CalcFrete {

    @Override
    public double calcularFrete(Carga carga) {

        if (carga.getPeso() <= 10) {
            return 12.56;
        } else if (carga.getPeso() <= 20) {
            return 14.99;
        } else {
            return 50;
        }

    }
}
