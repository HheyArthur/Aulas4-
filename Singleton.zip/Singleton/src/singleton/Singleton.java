/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singleton;

/**
 *
 * @author arthur.frguimaraes
 */
public class Singleton { //Lazy Singleton
    private static Singleton singlexarope;

   
    
    private Singleton() {
    }

   
    
    public static Singleton getSinglexarope() {
        if(singlexarope == null) {
            singlexarope = new Singleton();
    }
        return singlexarope;
        }
    
}
