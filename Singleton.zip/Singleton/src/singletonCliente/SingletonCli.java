/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package singletonCliente;

/**
 *
 * @author arthur.frguimaraes
 */
import singleton.Singleton;

public class SingletonCli extends Thread {

    @Override
    public void run() {

        Singleton s = Singleton.getSinglexarope();

        System.out.println(s);
    }

    public static void main(String[] args) {

        SingletonCli t1 = new SingletonCli();
        SingletonCli t2 = new SingletonCli();
        SingletonCli t3 = new SingletonCli();
        SingletonCli t4 = new SingletonCli();
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();

    }

}
