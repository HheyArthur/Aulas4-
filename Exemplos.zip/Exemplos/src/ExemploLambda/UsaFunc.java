/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ExemploLambda;

import java.util.*;
import java.util.function.Consumer;

/**
 *
 * @author arthur.frguimaraes
 */
public class UsaFunc {

    public static void main(String[] args) {

        List<Funcionario> Lista = new ArrayList<>();
        Lista.add(new Funcionario("Clovis", "Prof", 232456));
        Lista.add(new Funcionario("Cis", "Flanelinha", 236));
        Lista.add(new Funcionario("Clis", "Judge", 2326));

        // Lista Func
//        Consumer<Funcionario> consumer = new Consumer<>() {
//            @Override
//            public void accept(Funcionario funcionario) {
//            
//                System.out.println(funcionario);
//                
//            
//            }
//        }; // Classe anomina ou func lambda
        Consumer<Funcionario> consumer = (Funcionario funcionario)->{System.out.println(funcionario);};
        
        
        Lista.forEach(consumer);
    }

}
