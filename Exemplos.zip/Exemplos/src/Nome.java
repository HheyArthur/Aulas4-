/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author arthur.frguimaraes
 */
@FunctionalInterface
public interface Nome {
    
    public String getNome();
    
    default void exibir(String nome){
        System.out.println(nome);
    }
    
    
}
