/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author arthur.frguimaraes
 */
public class Teste {
    public static void main(String[] args) {
//        Nome nome = new Nome() {            // Lambda
//            @Override
//            public String getNome() {
//                return "Clovis";
//            }
//
//        
//    };
    
    Nome nome = ()->"Clovis"; // se tiver mais que uma instrução usar chaves e precisa coloca o return 
    
        nome.exibir(nome.getNome());
               
    
}
}      