/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemplos1;

/**
 *
 * @author arthur.frguimaraes
 */

import exemplos1.Externa.*;
import exemplos1.Externa.Interna; // Um ou outro


public class Exemplos1 {

    
    public static void main(String[] args) {
        
        Externa externa = new Externa();
        externa.exibir();
        Interna interna = externa.new Interna(); //Instanciando Classe Interna
        interna.exibir();


    }
    
}
