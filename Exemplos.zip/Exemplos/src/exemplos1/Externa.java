package exemplos1;

/**
 *
 * @author arthur.frguimaraes
 */
public class Externa {
    
    public void exibir (){
        System.out.println("Classe Externa");
        
        
    }
    
    public class Interna {
         public void exibir (){
        System.out.println("Classe interna");
        
        
    } 
        
    }
    
}

