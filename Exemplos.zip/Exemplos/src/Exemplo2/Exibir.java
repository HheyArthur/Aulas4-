/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Exemplo2;

/**
 *
 * @author arthur.frguimaraes
 */
public interface Exibir {
  
    public void exibirNome();
    public void exibirSobreNome();
    
    
    
}
