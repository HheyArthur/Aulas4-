/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exemplo2;


//class 

public class Test {
    
    public static void main(String[] args) {
     
        Exibir exibir= new Exibir() { // Declarando e criando a instancia da classe, uma classe anonima
            @Override
            public void exibirNome() {
                
                System.out.println("Gerson");
            }

            @Override
            public void exibirSobreNome() {
                System.out.println("Xaropada");
            }
        }; // Fim da classe anonima
        
        exibir.exibirNome();
        exibir.exibirSobreNome();
    }
     
    
    
}
