/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cliente;

/**
 *
 * @author murilo.scantante
 */
import fabrica.*;

public class Cliente {

    public static void main(String[] args) {

        Carro carro = FabricaVW.metodoFabrica(ListaCarrosVW.FOX);
        
        System.out.println(carro);
    }

}
