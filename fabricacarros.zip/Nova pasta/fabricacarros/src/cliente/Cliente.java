/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cliente;

/**
 *
 * @author murilo.scantante
 */
import fabrica.*;

public class Cliente {

    public static void main(String[] args) {

        // Polimorfismo
        
        Fabrica fabrica; 
        Carro carro = null;
        int tipo = 2;
        if (tipo==1) {
//            fabrica = new FabricaVW().metodoFabrica(carro); //<<
            fabrica = new FabricaVW();
            carro=fabrica.metodoFabrica(ListaCarrosVW.FOX);
        } else if (tipo==2) {
            fabrica = new FabricaGM();
            carro=fabrica.metodoFabrica(ListaCarrosGM.CELTA);
        }
              
        System.out.println(carro);
    }

}
