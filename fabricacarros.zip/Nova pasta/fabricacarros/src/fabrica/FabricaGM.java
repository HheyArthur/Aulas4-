/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabrica;

/**
 *
 * @author murilo.scantante
 */
public class FabricaGM implements Fabrica {

    
    @Override
    public  Carro metodoFabrica(Enum carro){
            if(carro.equals(ListaCarrosGM.ONIX)){
        return new Onix(12300,"ton");
        
        } else if (carro.equals(ListaCarrosGM.CELTA)){
        return new Celta(5300,"Cl"); 
        
        
        
    }
    return null;
}
}
