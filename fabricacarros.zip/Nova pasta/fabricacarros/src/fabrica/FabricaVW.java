/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabrica;

/**
 *
 * @author murilo.scantante
 */
public class FabricaVW implements Fabrica{
    
    @Override
    public  Carro metodoFabrica(Enum carro){
        if(carro.equals(ListaCarrosVW.FOX)){
        return new Fox(12300,"Cleyton");
        
        } else if (carro.equals(ListaCarrosVW.JETTA)){
        return new Fox(5300,"Cley"); 
        
        
        
    }
    return null;
}
}
