/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package fabrica;

/**
 *
 * @author murilo.scantante
 */
public interface Fabrica {
    
        public  Carro metodoFabrica(Enum carro);
        
        
        


    
}
