/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package fabrica;

/**
 *
 * @author murilo.scantante
 */
public enum ListaCarrosGM {
    ONIX,CELTA
}
